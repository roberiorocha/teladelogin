


script.js

const carrosselInterno = document.querySelector('.carrossel-interno');
const produtos = document.querySelectorAll('.produto');
const anterior = document.querySelector('.anterior');
const proximo = document.querySelector('.proximo');

let posicao = 0;

anterior.addEventListener('click', () => {
  if (posicao > 0) {
    posicao--;
    carrosselInterno.style.transform = `translateX(-${posicao * 320}px)`;
  }
});

proximo.addEventListener('click', () => {
  if (posicao < produtos.length - 3) {
    posicao++;
    carrosselInterno.style.transform = `translateX(-${posicao * 320}px)`;
  }
});

